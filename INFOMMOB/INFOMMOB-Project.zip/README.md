## gesture-camera-app ![gesture-camera-app](https://img.shields.io/npm/v/gesture-camera-app.svg)

> 

### Installation

```bash
$ npm install gesture-camera-app
```

### Example

```js
const gestureCameraApp = require('gesture-camera-app');

// your code here

```

### Contributing
- Fork this Repo first
- Clone your Repo
- Install dependencies by `$ npm install`
- Checkout a feature branch
- Feel free to add your features
- Make sure your features are fully tested
- Publish your local branch, Open a pull request
- Enjoy hacking <3

### MIT

This work is licensed under the [MIT license](./LICENSE).

---