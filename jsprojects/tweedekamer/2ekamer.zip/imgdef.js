var imgs = [];

imgs["NSC"] = new Image();
imgs["NSC"].src = "logos/NSC.png";

imgs["BvNL"] = new Image();
imgs["BvNL"].src = "logos/BvNL.png";

imgs["GL-PvdA"] = new Image();
imgs["GL-PvdA"].src = "logos/GvdL.png";

imgs["BIJ1"] = new Image();
imgs["BIJ1"].src = "logos/BIJ1.png";

imgs["BBB"] = new Image();
imgs["BBB"].src = "logos/BBB.png";

imgs["JL"] = new Image();
imgs["JL"].src = "logos/JL.png";

imgs["Volt"] = new Image();
imgs["Volt"].src = "logos/Volt.png";

imgs["JA21"] = new Image();
imgs["JA21"].src = "logos/JA21.png";

imgs["VVD"] = new Image();
imgs["VVD"].src = "logos/VVD.png";

imgs["PVV"] = new Image();
imgs["PVV"].src = "logos/PVV.png";

imgs["CDA"] = new Image();
imgs["CDA"].src = "logos/CDA.png";

imgs["D66"] = new Image();
imgs["D66"].src = "logos/D66.png";

imgs["GL"] = new Image();
imgs["GL"].src = "logos/GL.png";

imgs["SP"] = new Image();
imgs["SP"].src = "logos/SP.png";

imgs["PvdA"] = new Image();
imgs["PvdA"].src = "logos/PvdA.png";

imgs["CU"] = new Image();
imgs["CU"].src = "logos/CU.png";

imgs["PvdD"] = new Image();
imgs["PvdD"].src = "logos/PvdD.png";

imgs["50PLUS"] = new Image();
imgs["50PLUS"].src = "logos/50PLUS.png";

imgs["SGP"] = new Image();
imgs["SGP"].src = "logos/SGP.png";

imgs["DENK"] = new Image();
imgs["DENK"].src = "logos/DENK.png";

imgs["FvD"] = new Image();
imgs["FvD"].src = "logos/FvD.png";

imgs["LPF"] = new Image();
imgs["LPF"].src = "logos/LPF.png";

imgs["LN"] = new Image();
imgs["LN"].src = "logos/LN.png";

imgs["RPF"] = new Image();
imgs["RPF"].src = "logos/RPF.png";

imgs["GPV"] = new Image();
imgs["GPV"].src = "logos/GPV.png";

imgs["AOV"] = new Image();
imgs["AOV"].src = "logos/AOV.png";

imgs["CD"] = new Image();
imgs["CD"].src = "logos/CD.png";

imgs["Unie55+"] = new Image();
imgs["Unie55+"].src = "logos/Unie55+.png";

imgs["PPR"] = new Image();
imgs["PPR"].src = "logos/PPR.png";

imgs["PSP"] = new Image();
imgs["PSP"].src = "logos/PSP.png";

imgs["CPN"] = new Image();
imgs["CPN"].src = "logos/CPN.png";

imgs["EVP"] = new Image();
imgs["EVP"].src = "logos/EVP.png";

imgs["CP"] = new Image();
imgs["CP"].src = "logos/CP.png";

imgs["BP"] = new Image();
imgs["BP"].src = "logos/BP.png";

imgs["DS'70"] = new Image();
imgs["DS'70"].src = "logos/DS70.png";

imgs["KVP"] = new Image();
imgs["KVP"].src = "logos/KVP.png";

imgs["ARP"] = new Image();
imgs["ARP"].src = "logos/ARP.png";

imgs["CHU"] = new Image();
imgs["CHU"].src = "logos/CHU.png";

imgs["RKPN"] = new Image();
imgs["RKPN"].src = "logos/RKPN.png";

imgs["NMP"] = new Image();
imgs["NMP"].src = "logos/NMP.png";

imgs["KNP"] = new Image();
imgs["KNP"].src = "logos/KNP.png";

imgs["LW"] = new Image();
imgs["LW"].src = "logos/LW.png";

imgs["PvdV"] = new Image();
imgs["PvdV"].src = "logos/PvdV.png";

imgs["RKSP"] = new Image();
imgs["RKSP"].src = "logos/RKSP.png";

imgs["SDAP"] = new Image();
imgs["SDAP"].src = "logos/SDAP.png";

imgs["VDB"] = new Image();
imgs["VDB"].src = "logos/VDB.png";

imgs["NSB"] = new Image();
imgs["NSB"].src = "logos/NSB.png";

imgs["LSP"] = new Image();
imgs["LSP"].src = "logos/LSP.png";

imgs["CDU"] = new Image();
imgs["CDU"].src = "logos/CDU.png";

/*******************/

var arrow_left = new Image();
arrow_left.src = "sprites/arrow_left.png";

var arrow_right = new Image();
arrow_right.src = "sprites/arrow_right.png";

var inc_sprite = new Image();
inc_sprite.src = "sprites/increase.png";
inc_sprite.height = 16;

var dec_sprite = new Image();
dec_sprite.src = "sprites/decrease.png";
dec_sprite.height = 16;

var new_sprite = new Image();
new_sprite.src = "sprites/newcomer.png";
new_sprite.height = 16;

var nch_sprite = new Image();
nch_sprite.src = "sprites/nochange.png";
nch_sprite.height = 16;